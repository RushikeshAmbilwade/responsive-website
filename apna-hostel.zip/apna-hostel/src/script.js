// Event listener for login form submission
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();

    // Get the input values
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Basic validation (ensure fields are filled out)
    if (email && password) {
        // Hide the login form
        document.getElementById('login').style.display = 'none';

        // Show the services section
        document.getElementById('services').style.display = 'block';

        alert(`Login successful for ${email}`);
    } else {
        alert('Please fill out both fields!');
    }
});

// Event listeners for the service buttons
document.getElementById('room-service-btn').addEventListener('click', function() {
    document.getElementById('service-details').innerHTML = '<p>Room Service: Enjoy food and drink delivery to your room, 24/7!</p>';
});

document.getElementById('bathroom-service-btn').addEventListener('click', function() {
    document.getElementById('service-details').innerHTML = '<p>Bathroom Service: We provide daily cleaning and replenishment of bathroom amenities.</p>';
});

document.getElementById('laundry-service-btn').addEventListener('click', function() {
    document.getElementById('service-details').innerHTML = '<p>Laundry Service: Get your clothes washed, pressed, and delivered within hours.</p>';
});

// Rating System
const stars = document.querySelectorAll('.stars span');
let selectedRating = 0;

stars.forEach(star => {
    star.addEventListener('click', function() {
        selectedRating = parseInt(this.getAttribute('data-value'));
        stars.forEach(star => {
            if (parseInt(star.getAttribute('data-value')) <= selectedRating) {
                star.classList.add('selected');
            } else {
                star.classList.remove('selected');
            }
        });
        document.getElementById('rating-value').innerText = `Rating: ${selectedRating}/5`;
    });
});

// Task Assignment System
document.getElementById('assign-task-btn').addEventListener('click', function() {
    const selectedTask = document.getElementById('task-dropdown').value;
    const taskMessage = {
        'clean-room': 'You have assigned the task: Clean Room.',
        'clean-bathroom': 'You have assigned the task: Clean Bathroom.',
        'laundry': 'You have assigned the task: Laundry.'
    };
    document.getElementById('assigned-task-message').innerText = taskMessage[selectedTask];
});
